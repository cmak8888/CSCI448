package com.csci448.cmak_a2.ui.TheHistory

class GameFilter(o: Boolean, x: Boolean, p1: Boolean, p2: Boolean) {
    var filter_o = o
    var filter_x = x
    var filter_p1 = p1
    var filter_p2 = p2
}