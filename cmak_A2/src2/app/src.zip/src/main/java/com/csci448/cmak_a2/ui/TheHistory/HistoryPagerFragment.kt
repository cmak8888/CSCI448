package com.csci448.cmak_a2.ui.TheHistory

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import java.util.*

private const val logTag = "csci448.HistoryPager"
private const val ARG_GAME_ID = "game_id"

class HistoryPagerFragment : Fragment() {

    private lateinit var adapter : HistoryPagerAdapter
    private lateinit var gameId : UUID
    private lateinit var gamePagerViewModel : TheHistoryPagerViewModel

    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(logTag, "onCreate() called")

        val factory = TheHistoryPagerViewModelFactory(requireContext())
        gamePagerViewModel = ViewModelProvider(this, factory).get(TheHistoryPagerViewModel::class.java)
        gameId = arguments?.getSerializable(ARG_GAME_ID) as UUID
    }

    companion object {
        fun newInstance(gameId: UUID): HistoryDetailFragment {
            val args = Bundle().apply {
                putSerializable(ARG_GAME_ID, gameId)
            }
            return HistoryDetailFragment().apply {
                arguments = args
            }
        }
    }

}