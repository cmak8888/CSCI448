package com.csci448.cmak_a2.ui.TheHistory

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.csci448.cmak_a2.R
import com.csci448.cmak_a2.data.Game
import java.util.*

class HistoryFragment : Fragment() {
    interface Callbacks {
        fun onGameSelected(gameId: UUID)
    }

    private var callbacks: Callbacks? = null
    private val logTag = "448.HistoryListFrag"
    private lateinit var historyListViewModel: TheHistoryViewModel
    private lateinit var gameRecyclerView: RecyclerView
    private lateinit var adapter: HistoryListAdapter

    private fun updateUI(games: List<Game>) {
        adapter = HistoryListAdapter(games) {
                game: Game -> Unit
            callbacks?.onGameSelected(game.id)
        }
        gameRecyclerView.adapter = adapter
    }

    override fun onAttach(context : Context) {
        super.onAttach(context)
        Log.d(logTag, "onAttach() called")
        callbacks = context as Callbacks?
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(logTag, "onCreate() called")

        val factory = TheHistoryViewModelFactory(requireContext())
        historyListViewModel = ViewModelProvider(this, factory).get(TheHistoryViewModel::class.java)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.activity_historylist, container, false)
        gameRecyclerView = view.findViewById(R.id.history_list_recycler_view) as RecyclerView
        gameRecyclerView.layoutManager = LinearLayoutManager(context)
        updateUI(emptyList())

        Log.d(logTag,"onCreateView() called")
        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(logTag, "onViewCreated() called")
        historyListViewModel.gameListLiveData.observe(viewLifecycleOwner, Observer{
                games -> games?.let {
            Log.i(logTag, "Got Games ${games.size}")
            updateUI(games)
            }
        })
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.d(logTag,"onActivityCreated() called")
    }


    override fun onStart() {
        super.onStart()
        Log.d(logTag, "onStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(logTag, "onResume() called")
    }

    override fun onPause() {
        Log.d(logTag, "onPause() called")
        super.onPause()
    }

    override fun onStop() {
        Log.d(logTag, "onStop() called")
        super.onStop()
    }

    override fun onDestroyView() {
        Log.d(logTag, "onDestroyView called")
        super.onDestroyView()
    }

    override fun onDestroy() {
        Log.d(logTag, "onDestroy() called")
        super.onDestroy()
    }

    override fun onDetach() {
        Log.d(logTag, "onDetach() called")
        super.onDetach()

        callbacks = null
    }
}