package com.csci448.cmak_a2.ui.TheHistory

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import java.util.*

private const val LOG_TAG = "csci448.HistoryDetail"
private const val ARG_GAME_ID = "game_id"

class HistoryDetailFragment : Fragment() {


    private lateinit var gameDetailViewModel: TheHistoryDetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        Log.d(LOG_TAG, "onCreate() called")
        val factory = TheHistoryDetailViewModelFactory(requireContext())
        gameDetailViewModel = ViewModelProvider(this, factory).get(TheHistoryDetailViewModel::class.java)
        val gameId: UUID = arguments?.getSerializable(ARG_GAME_ID) as UUID
        gameDetailViewModel.loadGame(gameId)
        Log.d(LOG_TAG, "args bundle game ID: $gameId")
    }
    companion object {
        fun newInstance(gameId: UUID): HistoryDetailFragment {
            val args = Bundle().apply {
                putSerializable(ARG_GAME_ID, gameId)
            }
            return HistoryDetailFragment().apply {
                arguments = args
            }
        }
    }
}