package com.csci448.cmak_a2.data

class Config(playerNumber : Boolean, whichTile : Boolean, aiDifficulty : Boolean?) {
    var playerNum : Boolean = playerNumber;                 //true = 1 player
    var tile : Boolean = whichTile;                         //true = X
    var aiDiff : Boolean? = aiDifficulty;                   //true = hard
}